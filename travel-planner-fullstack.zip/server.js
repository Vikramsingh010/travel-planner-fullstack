const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "trips.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]");

function readTrips() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return []; }
}
function saveTrips(trips) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(trips, null, 2));
}

// Get all saved trips
app.get("/api/trips", (req, res) => res.json(readTrips()));

// Create a trip
app.post("/api/trips", (req, res) => {
  const { destination, startDate, endDate, budget, travelers, notes } = req.body;
  if (!destination || !startDate || !endDate) {
    return res.status(400).json({ message: "Destination, start date and end date are required." });
  }
  if (new Date(endDate) < new Date(startDate)) {
    return res.status(400).json({ message: "End date cannot be before start date." });
  }
  const trips = readTrips();
  const trip = {
    id: Date.now().toString(),
    destination: String(destination).trim(),
    startDate, endDate,
    budget: Number(budget) || 0,
    travelers: Math.max(1, Number(travelers) || 1),
    notes: String(notes || "").trim(),
    createdAt: new Date().toISOString()
  };
  trips.unshift(trip);
  saveTrips(trips);
  res.status(201).json(trip);
});

// Update a trip
app.put("/api/trips/:id", (req, res) => {
  const trips = readTrips();
  const index = trips.findIndex(t => t.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: "Trip not found." });
  const old = trips[index];
  const updated = { ...old, ...req.body, id: old.id };
  if (!updated.destination || !updated.startDate || !updated.endDate ||
      new Date(updated.endDate) < new Date(updated.startDate)) {
    return res.status(400).json({ message: "Please provide valid trip details and dates." });
  }
  updated.budget = Number(updated.budget) || 0;
  updated.travelers = Math.max(1, Number(updated.travelers) || 1);
  trips[index] = updated;
  saveTrips(trips);
  res.json(updated);
});

// Delete a trip
app.delete("/api/trips/:id", (req, res) => {
  const trips = readTrips();
  const remaining = trips.filter(t => t.id !== req.params.id);
  if (remaining.length === trips.length) return res.status(404).json({ message: "Trip not found." });
  saveTrips(remaining);
  res.json({ message: "Trip deleted successfully." });
});

app.get("/api/health", (req, res) => res.json({ status: "ok", message: "Travel Planner API is running." }));

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Travel Planner running at http://localhost:${PORT}`));
