const form = document.getElementById("trip-form");
const tripList = document.getElementById("trip-list");
const emptyState = document.getElementById("empty-state");
const errorBox = document.getElementById("form-error");
let trips = [];

const $ = id => document.getElementById(id);
const currency = value => new Intl.NumberFormat("en-IN", { style:"currency", currency:"INR", maximumFractionDigits:0 }).format(value || 0);
const dateLabel = value => new Date(value + "T00:00:00").toLocaleDateString("en-IN", { day:"numeric", month:"short", year:"numeric" });

async function api(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type":"application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Something went wrong.");
  return data;
}

async function loadTrips() {
  try {
    trips = await api("/api/trips");
    renderTrips();
  } catch (error) {
    errorBox.textContent = "Could not load trips. Please refresh the page.";
  }
}

function renderTrips() {
  const query = $("search").value.trim().toLowerCase();
  const filtered = trips.filter(t => t.destination.toLowerCase().includes(query));
  tripList.innerHTML = "";
  emptyState.classList.toggle("hidden", filtered.length > 0 || trips.length > 0);
  if (trips.length > 0 && filtered.length === 0) {
    tripList.innerHTML = '<p class="trip-caption">No destinations match your search.</p>';
  }
  filtered.forEach(trip => {
    const card = document.createElement("article");
    card.className = "trip-card";
    const top = document.createElement("div");
    top.className = "card-top";
    top.innerHTML = '<span class="trip-tag">UPCOMING ADVENTURE</span>';
    const actions = document.createElement("div");
    actions.className = "card-actions";
    const edit = document.createElement("button");
    edit.className = "icon-button"; edit.type = "button"; edit.title = "Edit trip"; edit.textContent = "✎";
    edit.addEventListener("click", () => editTrip(trip.id));
    const del = document.createElement("button");
    del.className = "icon-button"; del.type = "button"; del.title = "Delete trip"; del.textContent = "×";
    del.addEventListener("click", () => deleteTrip(trip.id));
    actions.append(edit, del); top.append(actions);
    const title = document.createElement("h3"); title.textContent = trip.destination;
    const dates = document.createElement("p"); dates.className = "trip-dates";
    dates.textContent = `${dateLabel(trip.startDate)} — ${dateLabel(trip.endDate)}`;
    const meta = document.createElement("div"); meta.className = "trip-meta";
    meta.textContent = `♙ ${trip.travelers} traveler${trip.travelers === 1 ? "" : "s"}`;
    const budget = document.createElement("div"); budget.className = "trip-budget";
    budget.textContent = `PLANNED BUDGET  ·  ${currency(trip.budget)}`;
    card.append(top, title, dates, meta, budget);
    if (trip.notes) { const notes = document.createElement("p"); notes.className = "trip-notes"; notes.textContent = trip.notes; card.append(notes); }
    tripList.append(card);
  });
  $("trip-count").textContent = trips.length;
  $("total-budget").textContent = currency(trips.reduce((sum, t) => sum + Number(t.budget || 0), 0));
  $("traveler-count").textContent = trips.reduce((sum, t) => sum + Number(t.travelers || 1), 0);
  $("trip-caption").textContent = `${trips.length} saved ${trips.length === 1 ? "trip" : "trips"}`;
}

function openForm(trip = null) {
  form.classList.remove("hidden");
  errorBox.textContent = "";
  $("form-title").textContent = trip ? "Edit your trip" : "Create your trip";
  $("trip-id").value = trip?.id || "";
  $("destination").value = trip?.destination || "";
  $("start-date").value = trip?.startDate || "";
  $("end-date").value = trip?.endDate || "";
  $("budget").value = trip?.budget ?? "";
  $("travelers").value = trip?.travelers || 1;
  $("notes").value = trip?.notes || "";
  form.scrollIntoView({ behavior:"smooth", block:"center" });
}
function closeForm() { form.classList.add("hidden"); form.reset(); $("trip-id").value = ""; errorBox.textContent = ""; }
function editTrip(id) { const trip = trips.find(t => t.id === id); if (trip) openForm(trip); }

async function deleteTrip(id) {
  if (!confirm("Delete this trip? This cannot be undone.")) return;
  try { await api(`/api/trips/${id}`, { method:"DELETE" }); await loadTrips(); }
  catch (error) { alert(error.message); }
}

form.addEventListener("submit", async event => {
  event.preventDefault();
  errorBox.textContent = "";
  const id = $("trip-id").value;
  const payload = {
    destination: $("destination").value.trim(),
    startDate: $("start-date").value,
    endDate: $("end-date").value,
    budget: Number($("budget").value) || 0,
    travelers: Number($("travelers").value) || 1,
    notes: $("notes").value.trim()
  };
  try {
    await api(id ? `/api/trips/${id}` : "/api/trips", {
      method: id ? "PUT" : "POST", body: JSON.stringify(payload)
    });
    closeForm(); await loadTrips();
  } catch (error) { errorBox.textContent = error.message; }
});

$("new-trip-btn").addEventListener("click", () => openForm());
$("empty-add").addEventListener("click", () => openForm());
$("close-form").addEventListener("click", closeForm);
$("cancel-form").addEventListener("click", closeForm);
$("search").addEventListener("input", renderTrips);
$("start-date").addEventListener("change", () => {
  $("end-date").min = $("start-date").value;
});
loadTrips();
